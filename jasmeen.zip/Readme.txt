Hello,

If there is a problem, question, or anything about my fonts, 
please sent an email to ketapelcreative@gmail.com

This demo font is for PERSONAL USE ONLY!
any donation are very appreciated,
( paypal.me/ketapelcreative )

Thank you for using my font


please, visit me:

https://dribbble.com/ketapelcreative
https://www.behance.net/ketapelcreative

https://id.pinterest.com/ketapelcreative/
https://twitter.com/KetapelCreative
https://www.linkedin.com/in/ketapel-creative-689a8a1a0/
https://www.instagram.com/ketapel.creative/

Best Regards
Ketapel creative

